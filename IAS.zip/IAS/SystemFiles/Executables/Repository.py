import os

RepositoryDirectory = os.getcwd()
print(RepositoryDirectory)

PythonPath = "/bin/python3"